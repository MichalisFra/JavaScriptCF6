export default function sayHello() {
    console.log("Hello!")
}
