import sayHello from "./greetings.js";
sayHello();