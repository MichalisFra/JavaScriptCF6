//1
const fname = 'Michalis'

console.log("Hello " + fname)





//2
const num1 = 10
const num2 = 20
const sum = num1 + num2
console.log(`Sum: ${sum}`)


//3
let isTrue = true;

console.log(isTrue ? `Είναι αλήθεια` : `Είναι ψευδές`)
